package com.ibm.xmlns.prod.websphere.j2ca.jde.geteffectiveaddresscontainebg;

/***** TOOL GENERATED CLASS, DO NOT EDIT ***/

import com.ibm.j2ca.extension.databinding.WBIDataBindingInterface;

public class GetEffectiveAddressContaineBGDataBinding extends com.ibm.j2ca.jde.emd.runtime.JDEDataBinding implements WBIDataBindingInterface {

	private String namespaceURI = "http://www.ibm.com/xmlns/prod/websphere/j2ca/jde/geteffectiveaddresscontainebg";
	private String businessObjectName = "GetEffectiveAddressContaineBG";
	private static final long serialVersionUID = -792524282812134567L;

	public String getNamespaceURI() {
		return namespaceURI;
	}

	public String getBusinessObjectName() {
		return businessObjectName;
	}
}