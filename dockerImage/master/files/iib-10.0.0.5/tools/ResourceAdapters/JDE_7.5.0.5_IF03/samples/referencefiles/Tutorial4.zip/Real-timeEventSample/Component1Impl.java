
import commonj.sdo.DataObject;
import com.ibm.websphere.sca.ServiceManager;

public class Component1Impl {
	/**
	 * Default constructor.
	 */
	public Component1Impl() {
		super();
	}

	/**
	 * Return a reference to the component service instance for this implementation
	 * class.  This method should be used when passing this service to a partner reference
	 * or if you want to invoke this component service asynchronously.    
	 *
	 * @generated (com.ibm.wbit.java)
	 */
	@SuppressWarnings("unused")
	private Object getMyService() {
		return (Object) ServiceManager.INSTANCE.locateService("self");
	}

	/**
	 * Method generated to support implemention of operation "emitCreateAfterImageRteRtcoout" defined for WSDL port type 
	 * named "JDEInboundInterface".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a parameter 
	 * type conveys that its a complex type. Please refer to the WSDL Definition for more information 
	 * on the type of input, output and fault(s).
	 */
	public void emitCreateAfterImageRteRtcoout(
			DataObject emitCreateAfterImageRteRtcooutInput) {
		System.out.println("Create");
		System.out.println(emitCreateAfterImageRteRtcooutInput.toString());
	}

	/**
	 * Method generated to support implemention of operation "emitUpdateAfterImageRteRtcoout" defined for WSDL port type 
	 * named "JDEInboundInterface".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a parameter 
	 * type conveys that its a complex type. Please refer to the WSDL Definition for more information 
	 * on the type of input, output and fault(s).
	 */
	public void emitUpdateAfterImageRteRtcoout(
			DataObject emitUpdateAfterImageRteRtcooutInput) {
		System.out.println("Update");
		System.out.println(emitUpdateAfterImageRteRtcooutInput.toString());
	}

	/**
	 * Method generated to support implemention of operation "emitDeleteAfterImageRteRtcoout" defined for WSDL port type 
	 * named "JDEInboundInterface".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a parameter 
	 * type conveys that its a complex type. Please refer to the WSDL Definition for more information 
	 * on the type of input, output and fault(s).
	 */
	public void emitDeleteAfterImageRteRtcoout(
			DataObject emitDeleteAfterImageRteRtcooutInput) {
		System.out.println("Delete");
		System.out.println(emitDeleteAfterImageRteRtcooutInput.toString());
	}

}