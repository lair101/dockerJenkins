package com.ibm.xmlns.prod.websphere.j2ca.jde.f0116query1bg;

/***** TOOL GENERATED CLASS, DO NOT EDIT ***/

import com.ibm.j2ca.extension.databinding.WBIDataBindingInterface;

public class F0116Query1BGDataBinding extends com.ibm.j2ca.jde.emd.runtime.JDEDataBinding implements WBIDataBindingInterface {

	private String namespaceURI = "http://www.ibm.com/xmlns/prod/websphere/j2ca/jde/f0116query1bg";
	private String businessObjectName = "F0116Query1BG";
	private static final long serialVersionUID = -792524282812134567L;

	public String getNamespaceURI() {
		return namespaceURI;
	}

	public String getBusinessObjectName() {
		return businessObjectName;
	}
}